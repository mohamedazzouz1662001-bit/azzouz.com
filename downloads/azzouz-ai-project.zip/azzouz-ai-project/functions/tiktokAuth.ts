// tiktokAuth — تبديل كود OAuth ديال TikTok بتوكن، والمفاتيح كتبقى فالسيرفر
const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS'
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: CORS });
  try {
    const body = await req.json().catch(() => ({}));
    const key = Deno.env.get('TIKTOK_CLIENT_KEY') || '';
    const secret = Deno.env.get('TIKTOK_CLIENT_SECRET') || '';
    if (!key || !secret) {
      return Response.json({
        ok: false,
        error: 'not_configured',
        error_description: 'خاص يتزادو TIKTOK_CLIENT_KEY و TIKTOK_CLIENT_SECRET فإعدادات المنصة قبل الربط.'
      }, { headers: CORS });
    }
    if (!body.code) return Response.json({ ok: false, error: 'missing_code' }, { headers: CORS });

    const form = new URLSearchParams({
      client_key: key,
      client_secret: secret,
      code: String(body.code),
      grant_type: 'authorization_code',
      redirect_uri: String(body.redirect_uri || '')
    });
    if (body.code_verifier) form.set('code_verifier', String(body.code_verifier));

    const r = await fetch('https://open.tiktokapis.com/v2/oauth/token/', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: form
    });
    const j = await r.json();
    return Response.json(j, { status: r.status, headers: CORS });
  } catch (e) {
    return Response.json({ ok: false, error: String((e && e.message) || e) }, { status: 500, headers: CORS });
  }
});
