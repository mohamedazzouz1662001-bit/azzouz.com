// tiktokAuth — تبديل كود OAuth ديال TikTok بتوكن، والمفاتيح كتبقى فالسيرفر
const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS'
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: CORS });
  try {
    const body = await req.json().catch(() => ({}));
    const key = Deno.env.get('TIKTOK_CLIENT_KEY') || '';
    const secret = Deno.env.get('TIKTOK_CLIENT_SECRET') || '';
    if (!key || !secret) {
      return Response.json({
        ok: false,
        error: 'not_configured',
        error_description: 'خاص يتزادو TIKTOK_CLIENT_KEY و TIKTOK_CLIENT_SECRET فإعدادات المنصة قبل الربط.'
      }, { headers: CORS });
    }
    const merchantMode = body.mode === 'merchant';
    if (!merchantMode && !body.code) return Response.json({ ok: false, error: 'missing_code' }, { headers: CORS });
    if (merchantMode && !body.refresh_token) return Response.json({ ok: false, error: 'missing_refresh_token' }, { headers: CORS });

    const merchant = body.mode === 'merchant';
    const endpoint = merchant
      ? 'https://open.tiktokapis.com/merchant/oauth/token/'
      : 'https://open.tiktokapis.com/v2/oauth/token/';

    const form = new URLSearchParams({ client_key: key, client_secret: secret });
    if (merchant) {
      form.set('grant_type', String(body.grant_type || 'refresh_token'));
      if (body.refresh_token) form.set('refresh_token', String(body.refresh_token));
    } else {
      form.set('grant_type', 'authorization_code');
      form.set('code', String(body.code || ''));
      form.set('redirect_uri', String(body.redirect_uri || ''));
      if (body.code_verifier) form.set('code_verifier', String(body.code_verifier));
    }

    const headers: Record<string, string> = { 'Content-Type': 'application/x-www-form-urlencoded' };
    if (merchant) headers['get-svc'] = '1';

    const r = await fetch(endpoint, { method: 'POST', headers, body: form });
    const j = await r.json();
    return Response.json(j, { status: r.status, headers: CORS });
  } catch (e) {
    return Response.json({ ok: false, error: String((e && e.message) || e) }, { status: 500, headers: CORS });
  }
});
