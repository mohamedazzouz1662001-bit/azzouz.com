// azzouzProxy — جسر قراءة عمومي: كيجيب أي صفحة ويب من السيرفر بلا قيود CORS
// ما كيديرش تسجيل دخول، ما كيحملش كوكيز، ما كيدخلش لشبكات داخلية.
const BLOCK = [
  /^localhost$/i, /^127\./, /^10\./, /^192\.168\./, /^172\.(1[6-9]|2\d|3[01])\./,
  /^169\.254\./, /^0\./, /^::1$/, /\.local$/i, /^metadata\./i
];

function allowed(target: string) {
  try {
    const u = new URL(target);
    if (!/^https?:$/.test(u.protocol)) return false;
    const h = u.hostname;
    if (BLOCK.some(r => r.test(h))) return false;
    return h.includes('.');
  } catch (e) {
    return false;
  }
}

Deno.serve(async (req) => {
  let url = '';
  try {
    const body = req.method === 'GET' ? {} : await req.json();
    url = (body as any)?.url || new URL(req.url).searchParams.get('url') || '';
  } catch (e) {
    url = new URL(req.url).searchParams.get('url') || '';
  }

  if (!url) return Response.json({ error: 'missing url' }, { status: 400 });
  if (!allowed(url)) return Response.json({ error: 'blocked url', url }, { status: 400 });

  const started = Date.now();
  try {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 15000);
    const r = await fetch(url, {
      signal: ctrl.signal,
      redirect: 'follow',
      headers: {
        'User-Agent': 'Mozilla/5.0 (compatible; AzzouzBot/1.0)',
        'Accept': 'text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8',
        'Accept-Language': 'ar,en;q=0.8'
      }
    });
    clearTimeout(timer);
    const raw = await r.text();
    const text = raw
      .replace(/<script[\s\S]*?<\/script>/gi, ' ')
      .replace(/<style[\s\S]*?<\/style>/gi, ' ')
      .replace(/<[^>]+>/g, ' ')
      .replace(/&nbsp;/g, ' ')
      .replace(/&amp;/g, '&')
      .replace(/\s+/g, ' ')
      .trim();
    return Response.json({
      ok: true,
      status: r.status,
      final_url: r.url,
      content_type: r.headers.get('content-type') || '',
      chars: text.length,
      ms: Date.now() - started,
      text: text.slice(0, 120000)
    });
  } catch (e) {
    return Response.json({ ok: false, error: String((e as any)?.message || e), ms: Date.now() - started });
  }
});
