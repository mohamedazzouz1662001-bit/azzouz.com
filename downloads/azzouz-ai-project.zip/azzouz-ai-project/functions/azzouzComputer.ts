// azzouzComputer — جسر بين واجهة Azzouz والحاسوب ديالك
// op=push  : الواجهة كتصيفط مهمة
// op=pull  : العامل المحلي كيجيب المهمة الجاية
// op=done  : العامل المحلي كيرجع النتيجة
// op=log   : الواجهة كتشوف آخر المهام
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';

const PAIR = 'AZZOUZ-PC-2026';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', {
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': '*',
        'Access-Control-Allow-Methods': 'POST,GET,OPTIONS'
      }
    });
  }

  let body: any = {};
  try { body = req.method === 'GET' ? {} : await req.json(); } catch (e) { body = {}; }

  const base44 = createClientFromRequest(req);
  const op = String(body.op || 'log');
  const key = String(body.key || '');

  if (key !== PAIR) return Response.json({ ok: false, error: 'bad key' }, { status: 401 });

  try {
    if (op === 'push') {
      const job = await base44.asServiceRole.entities.ComputerJob.create({
        job_id: 'j' + Date.now(),
        kind: String(body.kind || 'ask'),
        instruction: String(body.instruction || '').slice(0, 4000),
        status: 'queued',
        machine: String(body.machine || ''),
        secret: PAIR
      });
      return Response.json({ ok: true, job_id: (job as any)?.id || (job as any)?.job_id });
    }

    if (op === 'pull') {
      const page = await base44.asServiceRole.entities.ComputerJob.filter({ status: 'queued' }, { sort: 'created_date', limit: 1 });
      const job = (page?.items && page.items[0]) || null;
      if (!job) return Response.json({ ok: true, job: null });
      await base44.asServiceRole.entities.ComputerJob.update(job.id, { status: 'running' });
      return Response.json({ ok: true, job: { id: job.id, job_id: job.job_id, kind: job.kind, instruction: job.instruction } });
    }

    if (op === 'done') {
      const id = String(body.id || '');
      if (!id) return Response.json({ ok: false, error: 'missing id' }, { status: 400 });
      await base44.asServiceRole.entities.ComputerJob.update(id, {
        status: body.error ? 'error' : 'done',
        result: String(body.result || '').slice(0, 8000)
      });
      return Response.json({ ok: true });
    }



    if (op === 'job') {
      const id = String(body.id || '');
      if (!id) return Response.json({ ok: false, error: 'missing id' }, { status: 400 });
      const rows = await base44.asServiceRole.entities.ComputerJob.filter({ id }, { limit: 1 });
      const j = (rows?.items && rows.items[0]) || null;
      if (!j) return Response.json({ ok: false, error: 'not found' }, { status: 404 });
      return Response.json({ ok: true, status: j.status, result: String(j.result || '') });
    }

    if (op === 'beat') {
      const name = String(body.machine || 'pc');
      const found = await base44.asServiceRole.entities.Machine.filter({ name }, { limit: 1 });
      const row = (found?.items && found.items[0]) || null;
      const now = new Date().toISOString();
      if (row) await base44.asServiceRole.entities.Machine.update(row.id, { last_seen: now });
      else await base44.asServiceRole.entities.Machine.create({ name, last_seen: now });
      return Response.json({ ok: true, at: now });
    }

    if (op === 'state') {
      const page2 = await base44.asServiceRole.entities.Machine.list({ sort: '-last_seen', limit: 1 });
      const m = (page2?.items && page2.items[0]) || null;
      const at = m ? new Date(m.last_seen).getTime() : 0;
      return Response.json({ ok: true, machine: m?.name || '', last_seen: m?.last_seen || '', online: at > 0 && (Date.now() - at) < 45000 });
    }

    if (op === 'log') {
      const page = await base44.asServiceRole.entities.ComputerJob.list({ sort: '-created_date', limit: 8 });
      return Response.json({ ok: true, jobs: (page?.items || []).map((j: any) => ({ id: j.id, kind: j.kind, status: j.status, instruction: String(j.instruction || '').slice(0, 120), result: String(j.result || '').slice(0, 400), created: j.created_date })) });
    }

    return Response.json({ ok: false, error: 'unknown op' }, { status: 400 });
  } catch (e) {
    return Response.json({ ok: false, error: String((e as any)?.message || e) }, { status: 500 });
  }
});
