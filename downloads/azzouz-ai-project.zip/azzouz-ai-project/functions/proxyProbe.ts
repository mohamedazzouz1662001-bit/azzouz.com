export default async function handler(req, res) {
  const info = {
    method: req.method,
    hasQuery: !!(req.query && Object.keys(req.query).length),
    queryKeys: req.query ? Object.keys(req.query) : [],
    hasBody: !!req.body,
    bodyType: typeof req.body,
    hasFetch: typeof fetch,
    hasURL: typeof URL
  };
  try {
    const r = await fetch('https://example.com');
    info.fetchStatus = r.status;
    info.sample = (await r.text()).slice(0, 40);
  } catch (e) {
    info.fetchError = String(e && e.message || e);
  }
  return res.status(200).json(info);
}
