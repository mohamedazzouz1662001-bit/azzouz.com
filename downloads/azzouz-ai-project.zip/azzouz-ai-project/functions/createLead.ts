import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type',
};

Deno.serve(async (req) => {
  // preflight CORS
  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 204, headers: CORS });
  }
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ ok: false, error: 'POST only' }), {
      status: 405, headers: { ...CORS, 'Content-Type': 'application/json' },
    });
  }

  try {
    const body = await req.json().catch(() => ({}));
    const name = String(body.name || '').trim().slice(0, 100);
    const phone = String(body.phone || '').trim().slice(0, 30);
    const email = String(body.email || '').trim().slice(0, 150);
    const projectType = String(body.projectType || '').trim().slice(0, 50);
    const message = String(body.message || '').trim().slice(0, 3000);
    // honeypot ضد البوتات
    const trap = String(body.website || '').trim();

    if (!name || !message) {
      return new Response(JSON.stringify({ ok: false, error: 'الاسم والرسالة مطلوبان' }), {
        status: 400, headers: { ...CORS, 'Content-Type': 'application/json' },
      });
    }
    if (trap) {
      // بوت — جاوبو بنجاح باش ما يعرفش
      return new Response(JSON.stringify({ ok: true }), {
        status: 200, headers: { ...CORS, 'Content-Type': 'application/json' },
      });
    }

    const base44 = createClientFromRequest(req);
    const record = {
      name,
      phone,
      email,
      projectType,
      message,
      source: 'darnalab-site',
      status: 'new',
    };

    let created;
    try {
      created = await base44.entities.Lead.create(record);
    } catch (_e) {
      // فاش الزائر مجهول: خدم كـ service role
      created = await base44.asServiceRole.entities.Lead.create(record);
    }

    return new Response(JSON.stringify({ ok: true, id: created?.id || null }), {
      status: 200, headers: { ...CORS, 'Content-Type': 'application/json' },
    });
  } catch (e) {
    return new Response(JSON.stringify({ ok: false, error: 'server_error' }), {
      status: 500, headers: { ...CORS, 'Content-Type': 'application/json' },
    });
  }
});
