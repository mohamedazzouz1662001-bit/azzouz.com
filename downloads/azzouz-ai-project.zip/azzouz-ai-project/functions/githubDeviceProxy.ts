// githubDeviceProxy — وسيط آمن لـ GitHub Device Flow (بلا أي Client Secret)
// المسارات: /device/code · /token · /user · /health
// لا يسجل أي توكن ولا ينقله لأي طرف ثالث.

const ALLOWED_ORIGINS = [
  'https://mohamedazzouz1662001-bit.github.io',
  'https://elazzouz-dotcom.github.io',
  'http://localhost:3000',
  'http://localhost:8080',
];

const GH = {
  deviceCode: 'https://github.com/login/device/code',
  token: 'https://github.com/login/oauth/access_token',
  user: 'https://api.github.com/user',
};

function corsHeaders(req: Request): Record<string, string> {
  const origin = req.headers.get('origin') || '';
  const allow = ALLOWED_ORIGINS.includes(origin) ? origin : ALLOWED_ORIGINS[0];
  return {
    'Access-Control-Allow-Origin': allow,
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
    'Access-Control-Allow-Headers': 'content-type,authorization',
    'Access-Control-Max-Age': '86400',
    Vary: 'Origin',
  };
}

function json(data: unknown, status: number, req: Request) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...corsHeaders(req), 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' },
  });
}

Deno.serve(async (req) => {
  const cors = corsHeaders(req);
  if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors });

  const url = new URL(req.url);
  const parts = url.pathname.split('/').filter(Boolean);

  // الجسم يُقرأ مرة واحدة: ندعم المسار (/device/code) و?path= و action فالجسم
  const rawBody = req.method === 'POST' ? await req.text() : '';
  let bodyObj: Record<string, unknown> = {};
  try { bodyObj = rawBody ? JSON.parse(rawBody) : {}; } catch { bodyObj = {}; }

  const action = String(parts.slice(2).join('/') || url.searchParams.get('path') || bodyObj.action || '');

  try {
    if (action === 'health') {
      return json({ ok: true, service: 'github-device-proxy', time: new Date().toISOString() }, 200, req);
    }

    if (action === 'device/code' && req.method === 'POST') {
      const clientId = bodyObj.client_id as string;
      const scope = (bodyObj.scope as string) || 'read:user user:email';
      if (!clientId) return json({ error: 'missing_client_id' }, 400, req);

      const res = await fetch(GH.deviceCode, {
        method: 'POST',
        headers: { Accept: 'application/json', 'content-type': 'application/json' },
        body: JSON.stringify({ client_id: clientId, scope }),
      });
      const data = await res.json().catch(() => ({ error: 'invalid_response' }));

      if (data.error) return json(data, 400, req);
      if (!data.device_code) return json({ error: 'no_device_code', detail: data }, 502, req);
      return json(data, 200, req);
    }

    if (action === 'token' && req.method === 'POST') {
      const { client_id, device_code, grant_type } = bodyObj as Record<string, string>;
      if (!client_id || !device_code) return json({ error: 'missing_params' }, 400, req);

      const res = await fetch(GH.token, {
        method: 'POST',
        headers: { Accept: 'application/json', 'content-type': 'application/json' },
        body: JSON.stringify({
          client_id,
          device_code,
          grant_type: grant_type || 'urn:ietf:params:oauth:grant-type:device_code',
        }),
      });
      const data = await res.json().catch(() => ({ error: 'invalid_response' }));
      return json(data, res.status, req);
    }

    if (action === 'user' && req.method === 'GET') {
      const auth = req.headers.get('authorization') || '';
      if (!auth.toLowerCase().startsWith('bearer ')) return json({ error: 'missing_token' }, 401, req);

      const res = await fetch(GH.user, {
        headers: { Authorization: auth, Accept: 'application/vnd.github+json', 'User-Agent': 'Azzouz-Device-Proxy' },
      });
      const data = await res.json().catch(() => ({ error: 'invalid_response' }));
      return json(data, res.status, req);
    }

    return json({ error: 'not_found', action }, 404, req);
  } catch (e) {
    return json({ error: 'proxy_failure', detail: String((e as Error)?.message || e) }, 500, req);
  }
});
