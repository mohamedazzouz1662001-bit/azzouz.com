// tiktokShop — TikTok Shop Connector مستقلة: تجديد توكن التاجر وتخزينو فالسيرفر
// ملاحظة: هاد المسار ديال TikTok Shop، ما عندو حتى علاقة بصناديق LIVE ولا جمع العملات.
import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS'
};

const ENDPOINT = 'https://open.tiktokapis.com/merchant/oauth/token/';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: CORS });
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json().catch(() => ({}));
    const op = String(body.op || 'refresh');
    const key = Deno.env.get('TIKTOK_CLIENT_KEY') || '';
    const secret = Deno.env.get('TIKTOK_CLIENT_SECRET') || '';

    if (op === 'status') {
      const rows = await base44.asServiceRole.entities.TikTokMerchant.list({ sort: '-updated_date', limit: 1 });
      const m = (rows?.items && rows.items[0]) || null;
      if (!m) return Response.json({ ok: true, linked: false }, { headers: CORS });
      return Response.json({
        ok: true,
        linked: true,
        merchant_id: m.merchant_id || '',
        region: m.region || '',
        status: m.status || '',
        last_refresh: m.last_refresh || '',
        access_valid_for: m.access_exp ? Math.max(0, Math.round((m.access_exp - Date.now() / 1000))) : 0
      }, { headers: CORS });
    }

    if (!key || !secret) {
      return Response.json({
        ok: false,
        error: 'not_configured',
        error_description: 'TIKTOK_CLIENT_KEY و TIKTOK_CLIENT_SECRET خاصهم يتزادو فالإعدادات.'
      }, { headers: CORS });
    }

    const merchant_id = String(body.merchant_id || '');
    const refresh_token = String(body.refresh_token || '');
    const region = String(body.region || 'MA');
    if (!merchant_id) return Response.json({ ok: false, error: 'missing_merchant_id' }, { headers: CORS });
    if (!refresh_token) return Response.json({ ok: false, error: 'missing_refresh_token' }, { headers: CORS });

    const form = new URLSearchParams({
      client_key: key,
      client_secret: secret,
      merchant_id,
      grant_type: 'refresh_token',
      refresh_token
    });
    if (body.include_region) form.set('region', region);

    const r = await fetch(ENDPOINT, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'get-svc': '1', 'x-tt-target-idc': 'alisg' },
      body: form
    });
    const data = await r.json().catch(() => ({}));

    if (!r.ok || (data && (data.error || data.code))) {
      const err = String((data && (data.error || data.code)) || ('http_' + r.status));
      const rows = await base44.asServiceRole.entities.TikTokMerchant.filter({ merchant_id }, { limit: 1 });
      const row = (rows?.items && rows.items[0]) || null;
      if (row) await base44.asServiceRole.entities.TikTokMerchant.update(row.id, { status: 'error:' + err });
      return Response.json({
        ok: false,
        error: err,
        hint: err === 'invalid_grant' ? 'الريفريش توكن سالا ولا مرفوض: عاود دير التفويض.' : 'شوف صلاحيات التاجر والمنطقة.',
        http: r.status
      }, { status: 200, headers: CORS });
    }

    const now = Math.floor(Date.now() / 1000);
    const doc = {
      merchant_id,
      region,
      status: 'linked',
      access_token: String(data.access_token || ''),
      refresh_token: String(data.refresh_token || refresh_token),
      access_exp: now + Number(data.access_token_expire_in || data.expires_in || 0),
      refresh_exp: now + Number(data.refresh_token_expire_in || 0),
      last_refresh: new Date().toISOString()
    };
    const existing = await base44.asServiceRole.entities.TikTokMerchant.filter({ merchant_id }, { limit: 1 });
    const row = (existing?.items && existing.items[0]) || null;
    if (row) await base44.asServiceRole.entities.TikTokMerchant.update(row.id, doc);
    else await base44.asServiceRole.entities.TikTokMerchant.create(doc);

    return Response.json({
      ok: true,
      linked: true,
      merchant_id,
      access_valid_for: Math.max(0, doc.access_exp - now),
      refresh_rotated: String(data.refresh_token || '') !== '',
      last_refresh: doc.last_refresh
    }, { headers: CORS });
  } catch (e) {
    return Response.json({ ok: false, error: String((e && e.message) || e) }, { status: 500, headers: CORS });
  }
});
