# AZZOUZ AI — حزمة المشروع

## الملفات
azzouz-ai.html — الواجهة الكاملة (بحث، شات، حاسوب، تيك توك، Hunter).
boxhunter.mjs — TikTok Box Hunter: مراقبة، رادار، إشعارات، Silent Mode، OAuth.
azzouz-computer.mjs — العامل المحلي اللي كيكتب وينفذ على الحاسوب.
functions/ — دوال السيرفر: tiktokAuth (OAuth عادي)، tiktokShop + tiktokShopStatus (تاجر)، azzouzComputer، وغيرها.

## الدمج
import { initBoxHunter, stopWatcher } from './boxhunter.mjs';
await initBoxHunter(document.querySelector('#paneHunter'), { autoStart: true });
// للإيقاف: stopWatcher();

الصادرات: initBoxHunter, render, startWatcher, stopWatcher, tkConnect, tkDisconnect, tkFinish, tkStatus, tkToken.

## الأسرار (فالسيرفر فقط)
TIKTOK_CLIENT_KEY, TIKTOK_CLIENT_SECRET

## حدود معروفة
TikTok ما كتوفرش API عمومي لاكتشاف صناديق LIVE ولا جمع العملات.
الرادار كيستعمل مصادر عمومية (صفحات الوسوم وصفحات /live) للترشيح فقط، والتأكيد والجمع كيتدارو بيد المستخدم.
